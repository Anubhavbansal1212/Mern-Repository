const dotenv = require('dotenv');
const express = require('express');
const app = express();

dotenv.config({path: './config.env'});

require('./db/conn');
// const User = require('./model/userSchema');

 


const PORT = process.env.PORT;



// middelware

const middleware = (req, res, next) =>{
    console.log(`hello my middleware`)
    next();
}

app.get('/', (req,res) => {
    res.send(`hellp world`);
}); 

app.get('/about' , middleware, (req,res) => {
    res.send(`hello About world`);
});

app.get('/contact', (req,res) => {
    res.send(`hello contact world`);
});

app.get('/Signin', (req,res) => {
    res.send(`hello login world`);
});

app.get('/Signup', (req,res) => {
    res.send(`hello registration world`);
});



app.listen(PORT,() =>{
    console.log(`server is running at ${PORT}`)
});